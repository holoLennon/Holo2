/*
 * zmax 
 * 
 */

package com.holo.study;

/**
 * @author zmax
 *
 */
public class BaseEntity implements java.io.Serializable {
	public static final long serialVersionUID = 1L;
	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
