package com.holo.study;

public class BaseRepoAdmin {

}
